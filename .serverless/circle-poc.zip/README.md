# circleci_poc
A POC of a serverless circleCI pipeline
