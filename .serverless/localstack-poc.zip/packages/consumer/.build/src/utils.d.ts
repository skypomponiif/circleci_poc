export declare class RecordsNotFoundException extends Error {
}
export declare class FileNotUploadedException extends Error {
}
