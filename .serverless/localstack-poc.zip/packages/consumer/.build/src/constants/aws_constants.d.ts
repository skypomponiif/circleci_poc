export declare const ACCESS_KEY_ID: string;
export declare const ACCESS_KEY_SECRET: string;
export declare const BUCKET_NAME: string;
