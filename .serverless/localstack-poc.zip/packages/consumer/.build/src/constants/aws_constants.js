"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BUCKET_NAME = exports.ACCESS_KEY_SECRET = exports.ACCESS_KEY_ID = void 0;
exports.ACCESS_KEY_ID = process.env.ACCESS_KEY_ID ?? '';
exports.ACCESS_KEY_SECRET = process.env.ACCESS_KEY_SECRET ?? '';
exports.BUCKET_NAME = process.env.BUCKET_NAME ?? '';
//# sourceMappingURL=aws_constants.js.map