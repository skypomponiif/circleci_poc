import * as awsConstants from './aws_constants';
export declare const constants: {
    awsConstants: typeof awsConstants;
};
