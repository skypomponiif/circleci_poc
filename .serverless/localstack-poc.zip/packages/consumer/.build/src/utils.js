"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FileNotUploadedException = exports.RecordsNotFoundException = void 0;
class RecordsNotFoundException extends Error {
}
exports.RecordsNotFoundException = RecordsNotFoundException;
class FileNotUploadedException extends Error {
}
exports.FileNotUploadedException = FileNotUploadedException;
//# sourceMappingURL=utils.js.map