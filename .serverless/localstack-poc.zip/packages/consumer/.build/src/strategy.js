"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.uploadFile = exports.processDataToFile = exports.processRecords = void 0;
const utils_1 = require("./utils");
const constants_1 = require("./constants");
const { awsConstants } = constants_1.constants;
const processRecords = (records) => {
    if (!records)
        throw new utils_1.RecordsNotFoundException('Records cannot be null');
    const res = { valid: [], errors: [] };
    for (const record of records) {
        const payload = Buffer.from(record.kinesis.data, 'base64').toString('ascii');
        // TODO: Insert here validation logic
        res.valid.push(payload);
    }
    return res;
};
exports.processRecords = processRecords;
const processDataToFile = (records) => {
    let res = '';
    for (const record of records)
        res += record;
    return res;
};
exports.processDataToFile = processDataToFile;
const uploadFile = async (fileBody, s3) => {
    const params = {
        Bucket: awsConstants.BUCKET_NAME,
        Key: 'testFile.txt',
        Body: fileBody,
    };
    return new Promise((resolve, reject) => {
        s3.upload(params, (err, data) => {
            if (err)
                reject(new utils_1.FileNotUploadedException(err.message));
            console.log(`Uploaded file to ${data.Location} on Buclet -> ${data.Bucket}`);
            resolve(true);
        });
    });
};
exports.uploadFile = uploadFile;
//# sourceMappingURL=strategy.js.map