import { IProcessedRecords } from './interfaces';
import * as AWS from 'aws-sdk';
export declare const processRecords: (records: any) => IProcessedRecords;
export declare const processDataToFile: (records: Array<any>) => string;
export declare const uploadFile: (fileBody: string, s3: AWS.S3) => Promise<Boolean>;
