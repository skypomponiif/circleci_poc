// ----- TEST IMPORTS -----

import 'mocha';
import * as chai from 'chai';
import chaiAsPromised from 'chai-as-promised';
import * as sinon from 'sinon';
import sinonChai from 'sinon-chai';
chai.use(chaiAsPromised);
const expect = chai.expect;
chai.use(sinonChai);

// ----- END OF TEST IMPORTS -----
describe('Strategy tests', () => {
    describe('processRecords' () => {
        describe(' when passing')
    })
})