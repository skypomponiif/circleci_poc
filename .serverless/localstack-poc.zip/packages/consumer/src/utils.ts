export class RecordsNotFoundException extends Error {}
export class FileNotUploadedException extends Error {}
