import * as awsConstants from './aws_constants';

export const constants = {
	awsConstants,
};
