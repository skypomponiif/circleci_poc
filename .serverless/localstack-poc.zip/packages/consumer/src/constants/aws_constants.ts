export const ACCESS_KEY_ID = process.env.ACCESS_KEY_ID ?? '';
export const ACCESS_KEY_SECRET = process.env.ACCESS_KEY_SECRET ?? '';
export const BUCKET_NAME = process.env.BUCKET_NAME ?? '';
