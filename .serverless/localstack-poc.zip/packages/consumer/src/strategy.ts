import { IProcessedRecords } from './interfaces';
import { FileNotUploadedException, RecordsNotFoundException } from './utils';
import * as AWS from 'aws-sdk';
import { constants } from './constants';

const { awsConstants } = constants;
export const processRecords = (records: any): IProcessedRecords => {
	if (!records) throw new RecordsNotFoundException('Records cannot be null');
	const res: IProcessedRecords = { valid: [], errors: [] };
	for (const record of records) {
		const payload = Buffer.from(record.kinesis.data, 'base64').toString('ascii');
		// TODO: Insert here validation logic
		res.valid.push(payload);
	}

	return res;
};

export const processDataToFile = (records: Array<any>): string => {
	let res = '';
	for (const record of records) res += record;
	return res;
};

export const uploadFile = async (fileBody: string, s3: AWS.S3): Promise<Boolean> => {
	const params: AWS.S3.PutObjectRequest = {
		Bucket: awsConstants.BUCKET_NAME,
		Key: 'testFile.txt',
		Body: fileBody,
	};

	return new Promise((resolve,reject) => {
		s3.upload(params, (err: Error, data: AWS.S3.ManagedUpload.SendData) => {
			if (err) reject(new FileNotUploadedException(err.message));
			console.log(`Uploaded file to ${data.Location} on Buclet -> ${data.Bucket}`)
			resolve(true);
		});
	})
};
