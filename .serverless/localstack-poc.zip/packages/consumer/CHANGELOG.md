# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# [1.5.0](https://github.com/sky-uk/ita-videoplatform-public-api/compare/v1.4.4...v1.5.0) (2021-11-09)


### Features

* **CPSCALEUP-130:** Created consumer lambda for Kinesis Stream ([#127](https://github.com/sky-uk/ita-videoplatform-public-api/issues/127)) ([b3d5781](https://github.com/sky-uk/ita-videoplatform-public-api/commit/b3d5781af10b4a935b7160d96617c51174ddd2d4))





# Changelog
All notable changes to this project will be documented in this file.
